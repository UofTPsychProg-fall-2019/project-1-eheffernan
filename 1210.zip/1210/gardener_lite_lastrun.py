﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v3.1.2),
    on Tue Jan 21 08:52:44 2020
If you publish work using this script please cite the PsychoPy publications:
    Peirce, JW (2007) PsychoPy - Psychophysics software in Python.
        Journal of Neuroscience Methods, 162(1-2), 8-13.
    Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy.
        Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import absolute_import, division
from psychopy import locale_setup, sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '3.1.2'
expName = 'gardener_lite'  # from the Builder filename that created this script
expInfo = {'participant': ''}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='/Users/emilyheffernan/Desktop/Updated_Gardener_312/1210/gardener_lite_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=[2560, 1440], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "Pt1_Instr"
Pt1_InstrClock = core.Clock()
instruction_img = visual.ImageStim(
    win=win,
    name='instruction_img', 
    image='Instructions/gardenerInstructions.png', mask=None,
    ori=0, pos=(0, 0), size=(1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)

# Initialize components for Routine "tbOne"
tbOneClock = core.Clock()
crossHair = visual.TextStim(win=win, name='crossHair',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.2, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
Prompt = visual.ImageStim(
    win=win,
    name='Prompt', 
    image='Instructions/gardenerPrompt.png', mask=None,
    ori=0, pos=(0, 0), size=(1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
Flower = visual.ImageStim(
    win=win,
    name='Flower', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
RESPOND = visual.ImageStim(
    win=win,
    name='RESPOND', 
    image='Instructions/pleaseRespond.png', mask=None,
    ori=0, pos=(0, 0), size=(1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)

# Initialize components for Routine "fb_sc"
fb_scClock = core.Clock()
sunCorrect = visual.ImageStim(
    win=win,
    name='sunCorrect', 
    image='Instructions/feedback_sc.png', mask=None,
    ori=0, pos=(0, 0), size=(1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
flower_1 = visual.ImageStim(
    win=win,
    name='flower_1', 
    image='sin', mask=None,
    ori=0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)

# Initialize components for Routine "fb_si"
fb_siClock = core.Clock()
SunIncorrect = visual.ImageStim(
    win=win,
    name='SunIncorrect', 
    image='Instructions/feedback_si.png', mask=None,
    ori=0, pos=(0, 0), size=(1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
flower_2 = visual.ImageStim(
    win=win,
    name='flower_2', 
    image='sin', mask=None,
    ori=0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)

# Initialize components for Routine "fb_shc"
fb_shcClock = core.Clock()
ShadeCorrect = visual.ImageStim(
    win=win,
    name='ShadeCorrect', 
    image='Instructions/feedback_shc.png', mask=None,
    ori=0, pos=(0, 0), size=(1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
flower_3 = visual.ImageStim(
    win=win,
    name='flower_3', 
    image='sin', mask=None,
    ori=0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)

# Initialize components for Routine "fb_shi"
fb_shiClock = core.Clock()
ShadeIncorrect = visual.ImageStim(
    win=win,
    name='ShadeIncorrect', 
    image='Instructions/feedback_shi.png', mask=None,
    ori=0, pos=(0, 0), size=(1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)
flower_4 = visual.ImageStim(
    win=win,
    name='flower_4', 
    image='sin', mask=None,
    ori=0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)

# Initialize components for Routine "Break"
BreakClock = core.Clock()
TakeBreak = visual.ImageStim(
    win=win,
    name='TakeBreak', 
    image='Instructions/break.png', mask=None,
    ori=0, pos=(0, 0), size=(1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)

# Initialize components for Routine "Pt2_Instr"
Pt2_InstrClock = core.Clock()
pt2_instr = visual.ImageStim(
    win=win,
    name='pt2_instr', 
    image='Instructions/NoFeedback_Instructions.png', mask=None,
    ori=0, pos=(0, 0), size=(1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)

# Initialize components for Routine "NoFeedback"
NoFeedbackClock = core.Clock()
CrossHair = visual.TextStim(win=win, name='CrossHair',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
prompt = visual.ImageStim(
    win=win,
    name='prompt', 
    image='Instructions/gardenerPrompt.png', mask=None,
    ori=0, pos=(0, 0), size=(1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
nf_flower = visual.ImageStim(
    win=win,
    name='nf_flower', 
    image='sin', mask=None,
    ori=0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
plsRespond = visual.ImageStim(
    win=win,
    name='plsRespond', 
    image='Instructions/pleaseRespond.png', mask=None,
    ori=0, pos=(0, 0), size=(1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)

# Initialize components for Routine "Pt3_Instr"
Pt3_InstrClock = core.Clock()
Pt3_Instructions = visual.ImageStim(
    win=win,
    name='Pt3_Instructions', 
    image='Instructions/MemTest_Instructions.png', mask=None,
    ori=0, pos=(0, 0), size=(1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)

# Initialize components for Routine "MemTest"
MemTestClock = core.Clock()
Focus = visual.TextStim(win=win, name='Focus',
    text='+',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
mem_prompt = visual.ImageStim(
    win=win,
    name='mem_prompt', 
    image='Instructions/memPrompt.png', mask=None,
    ori=0, pos=(0, 0), size=(1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
mem_flower = visual.ImageStim(
    win=win,
    name='mem_flower', 
    image='sin', mask=None,
    ori=0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-2.0)
PlsResp = visual.ImageStim(
    win=win,
    name='PlsResp', 
    image='Instructions/pleaseRespond.png', mask=None,
    ori=0, pos=(0, 0), size=(1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-4.0)

# Initialize components for Routine "strategy"
strategyClock = core.Clock()
instr_strat = visual.TextStim(win=win, name='instr_strat',
    text='Please type out the strategy you were using to sort the flowers. Press enter when you are done.',
    font='Arial',
    pos=(-.2, .3), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
text = visual.TextStim(win=win, name='text',
    text=None,
    font='Arial',
    pos=(0, -.2), height=0.05, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "DONE"
DONEClock = core.Clock()
done = visual.ImageStim(
    win=win,
    name='done', 
    image='Instructions/done.png', mask=None,
    ori=0, pos=(0, 0), size=(1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "Pt1_Instr"-------
t = 0
Pt1_InstrClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
end_instr = keyboard.Keyboard()
# keep track of which components have finished
Pt1_InstrComponents = [instruction_img, end_instr]
for thisComponent in Pt1_InstrComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "Pt1_Instr"-------
while continueRoutine:
    # get current time
    t = Pt1_InstrClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instruction_img* updates
    if t >= 0.0 and instruction_img.status == NOT_STARTED:
        # keep track of start time/frame for later
        instruction_img.tStart = t  # not accounting for scr refresh
        instruction_img.frameNStart = frameN  # exact frame index
        win.timeOnFlip(instruction_img, 'tStartRefresh')  # time at next scr refresh
        instruction_img.setAutoDraw(True)
    
    # *end_instr* updates
    if t >= 0.0 and end_instr.status == NOT_STARTED:
        # keep track of start time/frame for later
        end_instr.tStart = t  # not accounting for scr refresh
        end_instr.frameNStart = frameN  # exact frame index
        win.timeOnFlip(end_instr, 'tStartRefresh')  # time at next scr refresh
        end_instr.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(end_instr.clock.reset)  # t=0 on next screen flip
        end_instr.clearEvents(eventType='keyboard')
    if end_instr.status == STARTED:
        theseKeys = end_instr.getKeys(keyList=['right'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            end_instr.keys = theseKeys.name  # just the last key pressed
            end_instr.rt = theseKeys.rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Pt1_InstrComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Pt1_Instr"-------
for thisComponent in Pt1_InstrComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if end_instr.keys in ['', [], None]:  # No response was made
    end_instr.keys = None
thisExp.addData('end_instr.keys',end_instr.keys)
if end_instr.keys != None:  # we had a response
    thisExp.addData('end_instr.rt', end_instr.rt)
thisExp.addData('end_instr.started', end_instr.tStartRefresh)
thisExp.addData('end_instr.stopped', end_instr.tStopRefresh)
thisExp.nextEntry()
# the Routine "Pt1_Instr" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
TaskBlocks = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Params_Lite/paramFile.csv'),
    seed=None, name='TaskBlocks')
thisExp.addLoop(TaskBlocks)  # add the loop to the experiment
thisTaskBlock = TaskBlocks.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTaskBlock.rgb)
if thisTaskBlock != None:
    for paramName in thisTaskBlock:
        exec('{} = thisTaskBlock[paramName]'.format(paramName))

for thisTaskBlock in TaskBlocks:
    currentLoop = TaskBlocks
    # abbreviate parameter names if possible (e.g. rgb = thisTaskBlock.rgb)
    if thisTaskBlock != None:
        for paramName in thisTaskBlock:
            exec('{} = thisTaskBlock[paramName]'.format(paramName))
    
    # set up handler to look after randomisation of conditions etc
    LearningTask = data.TrialHandler(nReps=1, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions(fileName),
        seed=None, name='LearningTask')
    thisExp.addLoop(LearningTask)  # add the loop to the experiment
    thisLearningTask = LearningTask.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisLearningTask.rgb)
    if thisLearningTask != None:
        for paramName in thisLearningTask:
            exec('{} = thisLearningTask[paramName]'.format(paramName))
    
    for thisLearningTask in LearningTask:
        currentLoop = LearningTask
        # abbreviate parameter names if possible (e.g. rgb = thisLearningTask.rgb)
        if thisLearningTask != None:
            for paramName in thisLearningTask:
                exec('{} = thisLearningTask[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "tbOne"-------
        t = 0
        tbOneClock.reset()  # clock
        frameN = -1
        continueRoutine = True
        # update component parameters for each repeat
        Flower.setPos((0, 0))
        Flower.setSize((0.5, 0.5))
        Flower.setImage(img)
        resp = keyboard.Keyboard()
        key_pleaseResp = keyboard.Keyboard()
        # keep track of which components have finished
        tbOneComponents = [crossHair, Prompt, Flower, resp, RESPOND, key_pleaseResp]
        for thisComponent in tbOneComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        # -------Start Routine "tbOne"-------
        while continueRoutine:
            # get current time
            t = tbOneClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *crossHair* updates
            if t >= 0.0 and crossHair.status == NOT_STARTED:
                # keep track of start time/frame for later
                crossHair.tStart = t  # not accounting for scr refresh
                crossHair.frameNStart = frameN  # exact frame index
                win.timeOnFlip(crossHair, 'tStartRefresh')  # time at next scr refresh
                crossHair.setAutoDraw(True)
            frameRemains = 0.0 + 0.5- win.monitorFramePeriod * 0.75  # most of one frame period left
            if crossHair.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                crossHair.tStop = t  # not accounting for scr refresh
                crossHair.frameNStop = frameN  # exact frame index
                win.timeOnFlip(crossHair, 'tStopRefresh')  # time at next scr refresh
                crossHair.setAutoDraw(False)
            
            # *Prompt* updates
            if t >= 0.5 and Prompt.status == NOT_STARTED:
                # keep track of start time/frame for later
                Prompt.tStart = t  # not accounting for scr refresh
                Prompt.frameNStart = frameN  # exact frame index
                win.timeOnFlip(Prompt, 'tStartRefresh')  # time at next scr refresh
                Prompt.setAutoDraw(True)
            frameRemains = 0.5 + 3- win.monitorFramePeriod * 0.75  # most of one frame period left
            if Prompt.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                Prompt.tStop = t  # not accounting for scr refresh
                Prompt.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Prompt, 'tStopRefresh')  # time at next scr refresh
                Prompt.setAutoDraw(False)
            
            # *Flower* updates
            if t >= 0.5 and Flower.status == NOT_STARTED:
                # keep track of start time/frame for later
                Flower.tStart = t  # not accounting for scr refresh
                Flower.frameNStart = frameN  # exact frame index
                win.timeOnFlip(Flower, 'tStartRefresh')  # time at next scr refresh
                Flower.setAutoDraw(True)
            frameRemains = 0.5 + 2.0- win.monitorFramePeriod * 0.75  # most of one frame period left
            if Flower.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                Flower.tStop = t  # not accounting for scr refresh
                Flower.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Flower, 'tStopRefresh')  # time at next scr refresh
                Flower.setAutoDraw(False)
            
            # *resp* updates
            if t >= 0.5 and resp.status == NOT_STARTED:
                # keep track of start time/frame for later
                resp.tStart = t  # not accounting for scr refresh
                resp.frameNStart = frameN  # exact frame index
                win.timeOnFlip(resp, 'tStartRefresh')  # time at next scr refresh
                resp.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(resp.clock.reset)  # t=0 on next screen flip
                resp.clearEvents(eventType='keyboard')
            frameRemains = 0.5 + 3- win.monitorFramePeriod * 0.75  # most of one frame period left
            if resp.status == STARTED and t >= frameRemains:
                # keep track of stop time/frame for later
                resp.tStop = t  # not accounting for scr refresh
                resp.frameNStop = frameN  # exact frame index
                win.timeOnFlip(resp, 'tStopRefresh')  # time at next scr refresh
                resp.status = FINISHED
            if resp.status == STARTED:
                theseKeys = resp.getKeys(keyList=['left', 'right'], waitRelease=False)
                if len(theseKeys):
                    theseKeys = theseKeys[0]  # at least one key was pressed
                    
                    # check for quit:
                    if "escape" == theseKeys:
                        endExpNow = True
                    resp.keys = theseKeys.name  # just the last key pressed
                    resp.rt = theseKeys.rt
                    # was this 'correct'?
                    if (resp.keys == str(category)) or (resp.keys == category):
                        resp.corr = 1
                    else:
                        resp.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # *RESPOND* updates
            if t >= 3.5 and RESPOND.status == NOT_STARTED:
                # keep track of start time/frame for later
                RESPOND.tStart = t  # not accounting for scr refresh
                RESPOND.frameNStart = frameN  # exact frame index
                win.timeOnFlip(RESPOND, 'tStartRefresh')  # time at next scr refresh
                RESPOND.setAutoDraw(True)
            
            # *key_pleaseResp* updates
            if t >= 3.5 and key_pleaseResp.status == NOT_STARTED:
                # keep track of start time/frame for later
                key_pleaseResp.tStart = t  # not accounting for scr refresh
                key_pleaseResp.frameNStart = frameN  # exact frame index
                win.timeOnFlip(key_pleaseResp, 'tStartRefresh')  # time at next scr refresh
                key_pleaseResp.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(key_pleaseResp.clock.reset)  # t=0 on next screen flip
                key_pleaseResp.clearEvents(eventType='keyboard')
            if key_pleaseResp.status == STARTED:
                theseKeys = key_pleaseResp.getKeys(keyList=['space'], waitRelease=False)
                if len(theseKeys):
                    theseKeys = theseKeys[0]  # at least one key was pressed
                    
                    # check for quit:
                    if "escape" == theseKeys:
                        endExpNow = True
                    key_pleaseResp.keys = theseKeys.name  # just the last key pressed
                    key_pleaseResp.rt = theseKeys.rt
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in tbOneComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "tbOne"-------
        for thisComponent in tbOneComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if resp.keys in ['', [], None]:  # No response was made
            resp.keys = None
            # was no response the correct answer?!
            if str(category).lower() == 'none':
               resp.corr = 1;  # correct non-response
            else:
               resp.corr = 0;  # failed to respond (incorrectly)
        # store data for LearningTask (TrialHandler)
        LearningTask.addData('resp.keys',resp.keys)
        LearningTask.addData('resp.corr', resp.corr)
        if resp.keys != None:  # we had a response
            LearningTask.addData('resp.rt', resp.rt)
        LearningTask.addData('resp.started', resp.tStartRefresh)
        LearningTask.addData('resp.stopped', resp.tStopRefresh)
        # check responses
        if key_pleaseResp.keys in ['', [], None]:  # No response was made
            key_pleaseResp.keys = None
        LearningTask.addData('key_pleaseResp.keys',key_pleaseResp.keys)
        if key_pleaseResp.keys != None:  # we had a response
            LearningTask.addData('key_pleaseResp.rt', key_pleaseResp.rt)
        LearningTask.addData('key_pleaseResp.started', key_pleaseResp.tStartRefresh)
        LearningTask.addData('key_pleaseResp.stopped', key_pleaseResp.tStopRefresh)
        #determine which feedback to provide
        flower = img
        rep_sc = 0
        rep_shc = 0
        rep_si = 0
        rep_shi = 0
        if resp.keys==category: #proper response
            if(category=='left'):
                rep_sc = 1
            else:
                rep_shc = 1
        else: #improper response
            if(category=='left'):
                rep_si = 1
            else:
                rep_shi = 1
                
        if key_pleaseResp.keys=='space': #no valid response provided
            rep_sc = 0
            rep_shc = 0
            rep_si = 0
            rep_shi = 0
        # the Routine "tbOne" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # set up handler to look after randomisation of conditions etc
        rep_sc = data.TrialHandler(nReps=rep_sc, method='random', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='rep_sc')
        thisExp.addLoop(rep_sc)  # add the loop to the experiment
        thisRep_sc = rep_sc.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisRep_sc.rgb)
        if thisRep_sc != None:
            for paramName in thisRep_sc:
                exec('{} = thisRep_sc[paramName]'.format(paramName))
        
        for thisRep_sc in rep_sc:
            currentLoop = rep_sc
            # abbreviate parameter names if possible (e.g. rgb = thisRep_sc.rgb)
            if thisRep_sc != None:
                for paramName in thisRep_sc:
                    exec('{} = thisRep_sc[paramName]'.format(paramName))
            
            # ------Prepare to start Routine "fb_sc"-------
            t = 0
            fb_scClock.reset()  # clock
            frameN = -1
            continueRoutine = True
            routineTimer.add(2.000000)
            # update component parameters for each repeat
            flower_1.setImage(flower)
            # keep track of which components have finished
            fb_scComponents = [sunCorrect, flower_1]
            for thisComponent in fb_scComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            
            # -------Start Routine "fb_sc"-------
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = fb_scClock.getTime()
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *sunCorrect* updates
                if t >= 0.0 and sunCorrect.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    sunCorrect.tStart = t  # not accounting for scr refresh
                    sunCorrect.frameNStart = frameN  # exact frame index
                    win.timeOnFlip(sunCorrect, 'tStartRefresh')  # time at next scr refresh
                    sunCorrect.setAutoDraw(True)
                frameRemains = 0.0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
                if sunCorrect.status == STARTED and t >= frameRemains:
                    # keep track of stop time/frame for later
                    sunCorrect.tStop = t  # not accounting for scr refresh
                    sunCorrect.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(sunCorrect, 'tStopRefresh')  # time at next scr refresh
                    sunCorrect.setAutoDraw(False)
                
                # *flower_1* updates
                if t >= 0 and flower_1.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    flower_1.tStart = t  # not accounting for scr refresh
                    flower_1.frameNStart = frameN  # exact frame index
                    win.timeOnFlip(flower_1, 'tStartRefresh')  # time at next scr refresh
                    flower_1.setAutoDraw(True)
                frameRemains = 0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
                if flower_1.status == STARTED and t >= frameRemains:
                    # keep track of stop time/frame for later
                    flower_1.tStop = t  # not accounting for scr refresh
                    flower_1.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(flower_1, 'tStopRefresh')  # time at next scr refresh
                    flower_1.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in fb_scComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "fb_sc"-------
            for thisComponent in fb_scComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
        # completed rep_sc repeats of 'rep_sc'
        
        
        # set up handler to look after randomisation of conditions etc
        rep_si = data.TrialHandler(nReps=rep_si, method='random', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='rep_si')
        thisExp.addLoop(rep_si)  # add the loop to the experiment
        thisRep_si = rep_si.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisRep_si.rgb)
        if thisRep_si != None:
            for paramName in thisRep_si:
                exec('{} = thisRep_si[paramName]'.format(paramName))
        
        for thisRep_si in rep_si:
            currentLoop = rep_si
            # abbreviate parameter names if possible (e.g. rgb = thisRep_si.rgb)
            if thisRep_si != None:
                for paramName in thisRep_si:
                    exec('{} = thisRep_si[paramName]'.format(paramName))
            
            # ------Prepare to start Routine "fb_si"-------
            t = 0
            fb_siClock.reset()  # clock
            frameN = -1
            continueRoutine = True
            routineTimer.add(2.000000)
            # update component parameters for each repeat
            flower_2.setImage(flower)
            # keep track of which components have finished
            fb_siComponents = [SunIncorrect, flower_2]
            for thisComponent in fb_siComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            
            # -------Start Routine "fb_si"-------
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = fb_siClock.getTime()
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *SunIncorrect* updates
                if t >= 0.0 and SunIncorrect.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    SunIncorrect.tStart = t  # not accounting for scr refresh
                    SunIncorrect.frameNStart = frameN  # exact frame index
                    win.timeOnFlip(SunIncorrect, 'tStartRefresh')  # time at next scr refresh
                    SunIncorrect.setAutoDraw(True)
                frameRemains = 0.0 + 2.0- win.monitorFramePeriod * 0.75  # most of one frame period left
                if SunIncorrect.status == STARTED and t >= frameRemains:
                    # keep track of stop time/frame for later
                    SunIncorrect.tStop = t  # not accounting for scr refresh
                    SunIncorrect.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(SunIncorrect, 'tStopRefresh')  # time at next scr refresh
                    SunIncorrect.setAutoDraw(False)
                
                # *flower_2* updates
                if t >= 0.0 and flower_2.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    flower_2.tStart = t  # not accounting for scr refresh
                    flower_2.frameNStart = frameN  # exact frame index
                    win.timeOnFlip(flower_2, 'tStartRefresh')  # time at next scr refresh
                    flower_2.setAutoDraw(True)
                frameRemains = 0.0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
                if flower_2.status == STARTED and t >= frameRemains:
                    # keep track of stop time/frame for later
                    flower_2.tStop = t  # not accounting for scr refresh
                    flower_2.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(flower_2, 'tStopRefresh')  # time at next scr refresh
                    flower_2.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in fb_siComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "fb_si"-------
            for thisComponent in fb_siComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
        # completed rep_si repeats of 'rep_si'
        
        
        # set up handler to look after randomisation of conditions etc
        rep_shc = data.TrialHandler(nReps=rep_shc, method='random', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='rep_shc')
        thisExp.addLoop(rep_shc)  # add the loop to the experiment
        thisRep_shc = rep_shc.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisRep_shc.rgb)
        if thisRep_shc != None:
            for paramName in thisRep_shc:
                exec('{} = thisRep_shc[paramName]'.format(paramName))
        
        for thisRep_shc in rep_shc:
            currentLoop = rep_shc
            # abbreviate parameter names if possible (e.g. rgb = thisRep_shc.rgb)
            if thisRep_shc != None:
                for paramName in thisRep_shc:
                    exec('{} = thisRep_shc[paramName]'.format(paramName))
            
            # ------Prepare to start Routine "fb_shc"-------
            t = 0
            fb_shcClock.reset()  # clock
            frameN = -1
            continueRoutine = True
            routineTimer.add(2.000000)
            # update component parameters for each repeat
            flower_3.setImage(flower)
            # keep track of which components have finished
            fb_shcComponents = [ShadeCorrect, flower_3]
            for thisComponent in fb_shcComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            
            # -------Start Routine "fb_shc"-------
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = fb_shcClock.getTime()
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *ShadeCorrect* updates
                if t >= 0.0 and ShadeCorrect.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    ShadeCorrect.tStart = t  # not accounting for scr refresh
                    ShadeCorrect.frameNStart = frameN  # exact frame index
                    win.timeOnFlip(ShadeCorrect, 'tStartRefresh')  # time at next scr refresh
                    ShadeCorrect.setAutoDraw(True)
                frameRemains = 0.0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
                if ShadeCorrect.status == STARTED and t >= frameRemains:
                    # keep track of stop time/frame for later
                    ShadeCorrect.tStop = t  # not accounting for scr refresh
                    ShadeCorrect.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(ShadeCorrect, 'tStopRefresh')  # time at next scr refresh
                    ShadeCorrect.setAutoDraw(False)
                
                # *flower_3* updates
                if t >= 0.0 and flower_3.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    flower_3.tStart = t  # not accounting for scr refresh
                    flower_3.frameNStart = frameN  # exact frame index
                    win.timeOnFlip(flower_3, 'tStartRefresh')  # time at next scr refresh
                    flower_3.setAutoDraw(True)
                frameRemains = 0.0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
                if flower_3.status == STARTED and t >= frameRemains:
                    # keep track of stop time/frame for later
                    flower_3.tStop = t  # not accounting for scr refresh
                    flower_3.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(flower_3, 'tStopRefresh')  # time at next scr refresh
                    flower_3.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in fb_shcComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "fb_shc"-------
            for thisComponent in fb_shcComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
        # completed rep_shc repeats of 'rep_shc'
        
        
        # set up handler to look after randomisation of conditions etc
        rep_shi = data.TrialHandler(nReps=rep_shi, method='random', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='rep_shi')
        thisExp.addLoop(rep_shi)  # add the loop to the experiment
        thisRep_shi = rep_shi.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisRep_shi.rgb)
        if thisRep_shi != None:
            for paramName in thisRep_shi:
                exec('{} = thisRep_shi[paramName]'.format(paramName))
        
        for thisRep_shi in rep_shi:
            currentLoop = rep_shi
            # abbreviate parameter names if possible (e.g. rgb = thisRep_shi.rgb)
            if thisRep_shi != None:
                for paramName in thisRep_shi:
                    exec('{} = thisRep_shi[paramName]'.format(paramName))
            
            # ------Prepare to start Routine "fb_shi"-------
            t = 0
            fb_shiClock.reset()  # clock
            frameN = -1
            continueRoutine = True
            routineTimer.add(2.000000)
            # update component parameters for each repeat
            flower_4.setImage(flower)
            # keep track of which components have finished
            fb_shiComponents = [ShadeIncorrect, flower_4]
            for thisComponent in fb_shiComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            
            # -------Start Routine "fb_shi"-------
            while continueRoutine and routineTimer.getTime() > 0:
                # get current time
                t = fb_shiClock.getTime()
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *ShadeIncorrect* updates
                if t >= 0.0 and ShadeIncorrect.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    ShadeIncorrect.tStart = t  # not accounting for scr refresh
                    ShadeIncorrect.frameNStart = frameN  # exact frame index
                    win.timeOnFlip(ShadeIncorrect, 'tStartRefresh')  # time at next scr refresh
                    ShadeIncorrect.setAutoDraw(True)
                frameRemains = 0.0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
                if ShadeIncorrect.status == STARTED and t >= frameRemains:
                    # keep track of stop time/frame for later
                    ShadeIncorrect.tStop = t  # not accounting for scr refresh
                    ShadeIncorrect.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(ShadeIncorrect, 'tStopRefresh')  # time at next scr refresh
                    ShadeIncorrect.setAutoDraw(False)
                
                # *flower_4* updates
                if t >= 0.0 and flower_4.status == NOT_STARTED:
                    # keep track of start time/frame for later
                    flower_4.tStart = t  # not accounting for scr refresh
                    flower_4.frameNStart = frameN  # exact frame index
                    win.timeOnFlip(flower_4, 'tStartRefresh')  # time at next scr refresh
                    flower_4.setAutoDraw(True)
                frameRemains = 0.0 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
                if flower_4.status == STARTED and t >= frameRemains:
                    # keep track of stop time/frame for later
                    flower_4.tStop = t  # not accounting for scr refresh
                    flower_4.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(flower_4, 'tStopRefresh')  # time at next scr refresh
                    flower_4.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in fb_shiComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # -------Ending Routine "fb_shi"-------
            for thisComponent in fb_shiComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
        # completed rep_shi repeats of 'rep_shi'
        
        thisExp.nextEntry()
        
    # completed 1 repeats of 'LearningTask'
    
    
    # ------Prepare to start Routine "Break"-------
    t = 0
    BreakClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    Break_break = keyboard.Keyboard()
    # keep track of which components have finished
    BreakComponents = [TakeBreak, Break_break]
    for thisComponent in BreakComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "Break"-------
    while continueRoutine:
        # get current time
        t = BreakClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *TakeBreak* updates
        if t >= 0.0 and TakeBreak.status == NOT_STARTED:
            # keep track of start time/frame for later
            TakeBreak.tStart = t  # not accounting for scr refresh
            TakeBreak.frameNStart = frameN  # exact frame index
            win.timeOnFlip(TakeBreak, 'tStartRefresh')  # time at next scr refresh
            TakeBreak.setAutoDraw(True)
        
        # *Break_break* updates
        if t >= 0.0 and Break_break.status == NOT_STARTED:
            # keep track of start time/frame for later
            Break_break.tStart = t  # not accounting for scr refresh
            Break_break.frameNStart = frameN  # exact frame index
            win.timeOnFlip(Break_break, 'tStartRefresh')  # time at next scr refresh
            Break_break.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(Break_break.clock.reset)  # t=0 on next screen flip
            Break_break.clearEvents(eventType='keyboard')
        if Break_break.status == STARTED:
            theseKeys = Break_break.getKeys(keyList=['space'], waitRelease=False)
            if len(theseKeys):
                theseKeys = theseKeys[0]  # at least one key was pressed
                
                # check for quit:
                if "escape" == theseKeys:
                    endExpNow = True
                Break_break.keys = theseKeys.name  # just the last key pressed
                Break_break.rt = theseKeys.rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in BreakComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Break"-------
    for thisComponent in BreakComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if Break_break.keys in ['', [], None]:  # No response was made
        Break_break.keys = None
    TaskBlocks.addData('Break_break.keys',Break_break.keys)
    if Break_break.keys != None:  # we had a response
        TaskBlocks.addData('Break_break.rt', Break_break.rt)
    TaskBlocks.addData('Break_break.started', Break_break.tStartRefresh)
    TaskBlocks.addData('Break_break.stopped', Break_break.tStopRefresh)
    # the Routine "Break" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
# completed 1 repeats of 'TaskBlocks'


# ------Prepare to start Routine "Pt2_Instr"-------
t = 0
Pt2_InstrClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_resp = keyboard.Keyboard()
# keep track of which components have finished
Pt2_InstrComponents = [pt2_instr, key_resp]
for thisComponent in Pt2_InstrComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "Pt2_Instr"-------
while continueRoutine:
    # get current time
    t = Pt2_InstrClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *pt2_instr* updates
    if t >= 0.0 and pt2_instr.status == NOT_STARTED:
        # keep track of start time/frame for later
        pt2_instr.tStart = t  # not accounting for scr refresh
        pt2_instr.frameNStart = frameN  # exact frame index
        win.timeOnFlip(pt2_instr, 'tStartRefresh')  # time at next scr refresh
        pt2_instr.setAutoDraw(True)
    
    # *key_resp* updates
    if t >= 0.0 and key_resp.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp.tStart = t  # not accounting for scr refresh
        key_resp.frameNStart = frameN  # exact frame index
        win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
        key_resp.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
        key_resp.clearEvents(eventType='keyboard')
    if key_resp.status == STARTED:
        theseKeys = key_resp.getKeys(keyList=['right'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            key_resp.keys = theseKeys.name  # just the last key pressed
            key_resp.rt = theseKeys.rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Pt2_InstrComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Pt2_Instr"-------
for thisComponent in Pt2_InstrComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('pt2_instr.started', pt2_instr.tStartRefresh)
thisExp.addData('pt2_instr.stopped', pt2_instr.tStopRefresh)
# check responses
if key_resp.keys in ['', [], None]:  # No response was made
    key_resp.keys = None
thisExp.addData('key_resp.keys',key_resp.keys)
if key_resp.keys != None:  # we had a response
    thisExp.addData('key_resp.rt', key_resp.rt)
thisExp.addData('key_resp.started', key_resp.tStartRefresh)
thisExp.addData('key_resp.stopped', key_resp.tStopRefresh)
thisExp.nextEntry()
# the Routine "Pt2_Instr" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
nf_trials = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Params_Lite/noFB.csv'),
    seed=None, name='nf_trials')
thisExp.addLoop(nf_trials)  # add the loop to the experiment
thisNf_trial = nf_trials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisNf_trial.rgb)
if thisNf_trial != None:
    for paramName in thisNf_trial:
        exec('{} = thisNf_trial[paramName]'.format(paramName))

for thisNf_trial in nf_trials:
    currentLoop = nf_trials
    # abbreviate parameter names if possible (e.g. rgb = thisNf_trial.rgb)
    if thisNf_trial != None:
        for paramName in thisNf_trial:
            exec('{} = thisNf_trial[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "NoFeedback"-------
    t = 0
    NoFeedbackClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    nf_flower.setImage(img)
    key_resp_2 = keyboard.Keyboard()
    pls_resp = keyboard.Keyboard()
    # keep track of which components have finished
    NoFeedbackComponents = [CrossHair, prompt, nf_flower, key_resp_2, plsRespond, pls_resp]
    for thisComponent in NoFeedbackComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "NoFeedback"-------
    while continueRoutine:
        # get current time
        t = NoFeedbackClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *CrossHair* updates
        if t >= 0.0 and CrossHair.status == NOT_STARTED:
            # keep track of start time/frame for later
            CrossHair.tStart = t  # not accounting for scr refresh
            CrossHair.frameNStart = frameN  # exact frame index
            win.timeOnFlip(CrossHair, 'tStartRefresh')  # time at next scr refresh
            CrossHair.setAutoDraw(True)
        frameRemains = 0.0 + 0.5- win.monitorFramePeriod * 0.75  # most of one frame period left
        if CrossHair.status == STARTED and t >= frameRemains:
            # keep track of stop time/frame for later
            CrossHair.tStop = t  # not accounting for scr refresh
            CrossHair.frameNStop = frameN  # exact frame index
            win.timeOnFlip(CrossHair, 'tStopRefresh')  # time at next scr refresh
            CrossHair.setAutoDraw(False)
        
        # *prompt* updates
        if t >= 0.5 and prompt.status == NOT_STARTED:
            # keep track of start time/frame for later
            prompt.tStart = t  # not accounting for scr refresh
            prompt.frameNStart = frameN  # exact frame index
            win.timeOnFlip(prompt, 'tStartRefresh')  # time at next scr refresh
            prompt.setAutoDraw(True)
        frameRemains = 0.5 + 3- win.monitorFramePeriod * 0.75  # most of one frame period left
        if prompt.status == STARTED and t >= frameRemains:
            # keep track of stop time/frame for later
            prompt.tStop = t  # not accounting for scr refresh
            prompt.frameNStop = frameN  # exact frame index
            win.timeOnFlip(prompt, 'tStopRefresh')  # time at next scr refresh
            prompt.setAutoDraw(False)
        
        # *nf_flower* updates
        if t >= 0.5 and nf_flower.status == NOT_STARTED:
            # keep track of start time/frame for later
            nf_flower.tStart = t  # not accounting for scr refresh
            nf_flower.frameNStart = frameN  # exact frame index
            win.timeOnFlip(nf_flower, 'tStartRefresh')  # time at next scr refresh
            nf_flower.setAutoDraw(True)
        frameRemains = 0.5 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
        if nf_flower.status == STARTED and t >= frameRemains:
            # keep track of stop time/frame for later
            nf_flower.tStop = t  # not accounting for scr refresh
            nf_flower.frameNStop = frameN  # exact frame index
            win.timeOnFlip(nf_flower, 'tStopRefresh')  # time at next scr refresh
            nf_flower.setAutoDraw(False)
        
        # *key_resp_2* updates
        if t >= 0.5 and key_resp_2.status == NOT_STARTED:
            # keep track of start time/frame for later
            key_resp_2.tStart = t  # not accounting for scr refresh
            key_resp_2.frameNStart = frameN  # exact frame index
            win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
            key_resp_2.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(key_resp_2.clock.reset)  # t=0 on next screen flip
            key_resp_2.clearEvents(eventType='keyboard')
        frameRemains = 0.5 + 3- win.monitorFramePeriod * 0.75  # most of one frame period left
        if key_resp_2.status == STARTED and t >= frameRemains:
            # keep track of stop time/frame for later
            key_resp_2.tStop = t  # not accounting for scr refresh
            key_resp_2.frameNStop = frameN  # exact frame index
            win.timeOnFlip(key_resp_2, 'tStopRefresh')  # time at next scr refresh
            key_resp_2.status = FINISHED
        if key_resp_2.status == STARTED:
            theseKeys = key_resp_2.getKeys(keyList=['left', 'right'], waitRelease=False)
            if len(theseKeys):
                theseKeys = theseKeys[0]  # at least one key was pressed
                
                # check for quit:
                if "escape" == theseKeys:
                    endExpNow = True
                key_resp_2.keys = theseKeys.name  # just the last key pressed
                key_resp_2.rt = theseKeys.rt
                # was this 'correct'?
                if (key_resp_2.keys == str(category)) or (key_resp_2.keys == category):
                    key_resp_2.corr = 1
                else:
                    key_resp_2.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *plsRespond* updates
        if t >= 3.5 and plsRespond.status == NOT_STARTED:
            # keep track of start time/frame for later
            plsRespond.tStart = t  # not accounting for scr refresh
            plsRespond.frameNStart = frameN  # exact frame index
            win.timeOnFlip(plsRespond, 'tStartRefresh')  # time at next scr refresh
            plsRespond.setAutoDraw(True)
        
        # *pls_resp* updates
        if t >= 3.5 and pls_resp.status == NOT_STARTED:
            # keep track of start time/frame for later
            pls_resp.tStart = t  # not accounting for scr refresh
            pls_resp.frameNStart = frameN  # exact frame index
            win.timeOnFlip(pls_resp, 'tStartRefresh')  # time at next scr refresh
            pls_resp.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(pls_resp.clock.reset)  # t=0 on next screen flip
            pls_resp.clearEvents(eventType='keyboard')
        if pls_resp.status == STARTED:
            theseKeys = pls_resp.getKeys(keyList=['space'], waitRelease=False)
            if len(theseKeys):
                theseKeys = theseKeys[0]  # at least one key was pressed
                
                # check for quit:
                if "escape" == theseKeys:
                    endExpNow = True
                pls_resp.keys = theseKeys.name  # just the last key pressed
                pls_resp.rt = theseKeys.rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in NoFeedbackComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "NoFeedback"-------
    for thisComponent in NoFeedbackComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if key_resp_2.keys in ['', [], None]:  # No response was made
        key_resp_2.keys = None
        # was no response the correct answer?!
        if str(category).lower() == 'none':
           key_resp_2.corr = 1;  # correct non-response
        else:
           key_resp_2.corr = 0;  # failed to respond (incorrectly)
    # store data for nf_trials (TrialHandler)
    nf_trials.addData('key_resp_2.keys',key_resp_2.keys)
    nf_trials.addData('key_resp_2.corr', key_resp_2.corr)
    if key_resp_2.keys != None:  # we had a response
        nf_trials.addData('key_resp_2.rt', key_resp_2.rt)
    nf_trials.addData('key_resp_2.started', key_resp_2.tStartRefresh)
    nf_trials.addData('key_resp_2.stopped', key_resp_2.tStopRefresh)
    # check responses
    if pls_resp.keys in ['', [], None]:  # No response was made
        pls_resp.keys = None
    nf_trials.addData('pls_resp.keys',pls_resp.keys)
    if pls_resp.keys != None:  # we had a response
        nf_trials.addData('pls_resp.rt', pls_resp.rt)
    nf_trials.addData('pls_resp.started', pls_resp.tStartRefresh)
    nf_trials.addData('pls_resp.stopped', pls_resp.tStopRefresh)
    # the Routine "NoFeedback" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1 repeats of 'nf_trials'


# ------Prepare to start Routine "Pt3_Instr"-------
t = 0
Pt3_InstrClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_resp_3 = keyboard.Keyboard()
# keep track of which components have finished
Pt3_InstrComponents = [Pt3_Instructions, key_resp_3]
for thisComponent in Pt3_InstrComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "Pt3_Instr"-------
while continueRoutine:
    # get current time
    t = Pt3_InstrClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *Pt3_Instructions* updates
    if t >= 0.0 and Pt3_Instructions.status == NOT_STARTED:
        # keep track of start time/frame for later
        Pt3_Instructions.tStart = t  # not accounting for scr refresh
        Pt3_Instructions.frameNStart = frameN  # exact frame index
        win.timeOnFlip(Pt3_Instructions, 'tStartRefresh')  # time at next scr refresh
        Pt3_Instructions.setAutoDraw(True)
    
    # *key_resp_3* updates
    if t >= 0.0 and key_resp_3.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_3.tStart = t  # not accounting for scr refresh
        key_resp_3.frameNStart = frameN  # exact frame index
        win.timeOnFlip(key_resp_3, 'tStartRefresh')  # time at next scr refresh
        key_resp_3.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(key_resp_3.clock.reset)  # t=0 on next screen flip
        key_resp_3.clearEvents(eventType='keyboard')
    if key_resp_3.status == STARTED:
        theseKeys = key_resp_3.getKeys(keyList=['right'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            key_resp_3.keys = theseKeys.name  # just the last key pressed
            key_resp_3.rt = theseKeys.rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Pt3_InstrComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Pt3_Instr"-------
for thisComponent in Pt3_InstrComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_resp_3.keys in ['', [], None]:  # No response was made
    key_resp_3.keys = None
thisExp.addData('key_resp_3.keys',key_resp_3.keys)
if key_resp_3.keys != None:  # we had a response
    thisExp.addData('key_resp_3.rt', key_resp_3.rt)
thisExp.addData('key_resp_3.started', key_resp_3.tStartRefresh)
thisExp.addData('key_resp_3.stopped', key_resp_3.tStopRefresh)
thisExp.nextEntry()
# the Routine "Pt3_Instr" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
Mem_Loop = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Params_Lite/recBlock.csv'),
    seed=None, name='Mem_Loop')
thisExp.addLoop(Mem_Loop)  # add the loop to the experiment
thisMem_Loop = Mem_Loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisMem_Loop.rgb)
if thisMem_Loop != None:
    for paramName in thisMem_Loop:
        exec('{} = thisMem_Loop[paramName]'.format(paramName))

for thisMem_Loop in Mem_Loop:
    currentLoop = Mem_Loop
    # abbreviate parameter names if possible (e.g. rgb = thisMem_Loop.rgb)
    if thisMem_Loop != None:
        for paramName in thisMem_Loop:
            exec('{} = thisMem_Loop[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "MemTest"-------
    t = 0
    MemTestClock.reset()  # clock
    frameN = -1
    continueRoutine = True
    # update component parameters for each repeat
    mem_flower.setImage(img)
    oldNew = keyboard.Keyboard()
    plsResp = keyboard.Keyboard()
    # keep track of which components have finished
    MemTestComponents = [Focus, mem_prompt, mem_flower, oldNew, PlsResp, plsResp]
    for thisComponent in MemTestComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    # -------Start Routine "MemTest"-------
    while continueRoutine:
        # get current time
        t = MemTestClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Focus* updates
        if t >= 0.0 and Focus.status == NOT_STARTED:
            # keep track of start time/frame for later
            Focus.tStart = t  # not accounting for scr refresh
            Focus.frameNStart = frameN  # exact frame index
            win.timeOnFlip(Focus, 'tStartRefresh')  # time at next scr refresh
            Focus.setAutoDraw(True)
        frameRemains = 0.0 + 0.5- win.monitorFramePeriod * 0.75  # most of one frame period left
        if Focus.status == STARTED and t >= frameRemains:
            # keep track of stop time/frame for later
            Focus.tStop = t  # not accounting for scr refresh
            Focus.frameNStop = frameN  # exact frame index
            win.timeOnFlip(Focus, 'tStopRefresh')  # time at next scr refresh
            Focus.setAutoDraw(False)
        
        # *mem_prompt* updates
        if t >= 0.5 and mem_prompt.status == NOT_STARTED:
            # keep track of start time/frame for later
            mem_prompt.tStart = t  # not accounting for scr refresh
            mem_prompt.frameNStart = frameN  # exact frame index
            win.timeOnFlip(mem_prompt, 'tStartRefresh')  # time at next scr refresh
            mem_prompt.setAutoDraw(True)
        frameRemains = 0.5 + 3- win.monitorFramePeriod * 0.75  # most of one frame period left
        if mem_prompt.status == STARTED and t >= frameRemains:
            # keep track of stop time/frame for later
            mem_prompt.tStop = t  # not accounting for scr refresh
            mem_prompt.frameNStop = frameN  # exact frame index
            win.timeOnFlip(mem_prompt, 'tStopRefresh')  # time at next scr refresh
            mem_prompt.setAutoDraw(False)
        
        # *mem_flower* updates
        if t >= 0.5 and mem_flower.status == NOT_STARTED:
            # keep track of start time/frame for later
            mem_flower.tStart = t  # not accounting for scr refresh
            mem_flower.frameNStart = frameN  # exact frame index
            win.timeOnFlip(mem_flower, 'tStartRefresh')  # time at next scr refresh
            mem_flower.setAutoDraw(True)
        frameRemains = 0.5 + 2- win.monitorFramePeriod * 0.75  # most of one frame period left
        if mem_flower.status == STARTED and t >= frameRemains:
            # keep track of stop time/frame for later
            mem_flower.tStop = t  # not accounting for scr refresh
            mem_flower.frameNStop = frameN  # exact frame index
            win.timeOnFlip(mem_flower, 'tStopRefresh')  # time at next scr refresh
            mem_flower.setAutoDraw(False)
        
        # *oldNew* updates
        if t >= 0.5 and oldNew.status == NOT_STARTED:
            # keep track of start time/frame for later
            oldNew.tStart = t  # not accounting for scr refresh
            oldNew.frameNStart = frameN  # exact frame index
            win.timeOnFlip(oldNew, 'tStartRefresh')  # time at next scr refresh
            oldNew.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(oldNew.clock.reset)  # t=0 on next screen flip
            oldNew.clearEvents(eventType='keyboard')
        frameRemains = 0.5 + 3- win.monitorFramePeriod * 0.75  # most of one frame period left
        if oldNew.status == STARTED and t >= frameRemains:
            # keep track of stop time/frame for later
            oldNew.tStop = t  # not accounting for scr refresh
            oldNew.frameNStop = frameN  # exact frame index
            win.timeOnFlip(oldNew, 'tStopRefresh')  # time at next scr refresh
            oldNew.status = FINISHED
        if oldNew.status == STARTED:
            theseKeys = oldNew.getKeys(keyList=['left', 'right'], waitRelease=False)
            if len(theseKeys):
                theseKeys = theseKeys[0]  # at least one key was pressed
                
                # check for quit:
                if "escape" == theseKeys:
                    endExpNow = True
                oldNew.keys = theseKeys.name  # just the last key pressed
                oldNew.rt = theseKeys.rt
                # was this 'correct'?
                if (oldNew.keys == str(resp)) or (oldNew.keys == resp):
                    oldNew.corr = 1
                else:
                    oldNew.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *PlsResp* updates
        if t >= 3.5 and PlsResp.status == NOT_STARTED:
            # keep track of start time/frame for later
            PlsResp.tStart = t  # not accounting for scr refresh
            PlsResp.frameNStart = frameN  # exact frame index
            win.timeOnFlip(PlsResp, 'tStartRefresh')  # time at next scr refresh
            PlsResp.setAutoDraw(True)
        
        # *plsResp* updates
        if t >= 3.5 and plsResp.status == NOT_STARTED:
            # keep track of start time/frame for later
            plsResp.tStart = t  # not accounting for scr refresh
            plsResp.frameNStart = frameN  # exact frame index
            win.timeOnFlip(plsResp, 'tStartRefresh')  # time at next scr refresh
            plsResp.status = STARTED
            # keyboard checking is just starting
            win.callOnFlip(plsResp.clock.reset)  # t=0 on next screen flip
            plsResp.clearEvents(eventType='keyboard')
        if plsResp.status == STARTED:
            theseKeys = plsResp.getKeys(keyList=['space'], waitRelease=False)
            if len(theseKeys):
                theseKeys = theseKeys[0]  # at least one key was pressed
                
                # check for quit:
                if "escape" == theseKeys:
                    endExpNow = True
                plsResp.keys = theseKeys.name  # just the last key pressed
                plsResp.rt = theseKeys.rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in MemTestComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "MemTest"-------
    for thisComponent in MemTestComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if oldNew.keys in ['', [], None]:  # No response was made
        oldNew.keys = None
        # was no response the correct answer?!
        if str(resp).lower() == 'none':
           oldNew.corr = 1;  # correct non-response
        else:
           oldNew.corr = 0;  # failed to respond (incorrectly)
    # store data for Mem_Loop (TrialHandler)
    Mem_Loop.addData('oldNew.keys',oldNew.keys)
    Mem_Loop.addData('oldNew.corr', oldNew.corr)
    if oldNew.keys != None:  # we had a response
        Mem_Loop.addData('oldNew.rt', oldNew.rt)
    Mem_Loop.addData('oldNew.started', oldNew.tStartRefresh)
    Mem_Loop.addData('oldNew.stopped', oldNew.tStopRefresh)
    # check responses
    if plsResp.keys in ['', [], None]:  # No response was made
        plsResp.keys = None
    Mem_Loop.addData('plsResp.keys',plsResp.keys)
    if plsResp.keys != None:  # we had a response
        Mem_Loop.addData('plsResp.rt', plsResp.rt)
    Mem_Loop.addData('plsResp.started', plsResp.tStartRefresh)
    Mem_Loop.addData('plsResp.stopped', plsResp.tStopRefresh)
    # the Routine "MemTest" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1 repeats of 'Mem_Loop'


# ------Prepare to start Routine "strategy"-------
t = 0
strategyClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
#Initialize variable to store typing and clear current events
modify = False
text.text = 'Response: '
event.clearEvents('keyboard')
# keep track of which components have finished
strategyComponents = [instr_strat, text]
for thisComponent in strategyComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "strategy"-------
while continueRoutine:
    # get current time
    t = strategyClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instr_strat* updates
    if t >= 0.0 and instr_strat.status == NOT_STARTED:
        # keep track of start time/frame for later
        instr_strat.tStart = t  # not accounting for scr refresh
        instr_strat.frameNStart = frameN  # exact frame index
        win.timeOnFlip(instr_strat, 'tStartRefresh')  # time at next scr refresh
        instr_strat.setAutoDraw(True)
    
    # *text* updates
    if t >= 0.0 and text.status == NOT_STARTED:
        # keep track of start time/frame for later
        text.tStart = t  # not accounting for scr refresh
        text.frameNStart = frameN  # exact frame index
        win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
        text.setAutoDraw(True)
    #Store new data (and store punctuation as punctuation)
    keys = event.getKeys()
    if len(keys):
        if 'space' in keys:
            text.text = text.text + ' '
        elif 'period' in keys:
            text.text = text.text + '.'
        elif 'comma' in keys:
            text.text = text.text + ','
        elif 'apostrophe' in keys:
            text.text = text.text + '\''
        elif 'backspace' in keys:
            text.text = text.text[:-1]
        elif 'lshift' in keys or 'rshift' in keys:
            modify = True
        elif 'return' in keys:
            continueRoutine = False
        else:
            if modify:
                text.text = text.text + keys[0].upper()
                modify = False
            else:
                text.text = text.text + keys[0]
    
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in strategyComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "strategy"-------
for thisComponent in strategyComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('instr_strat.started', instr_strat.tStartRefresh)
thisExp.addData('instr_strat.stopped', instr_strat.tStopRefresh)
thisExp.addData('text.started', text.tStartRefresh)
thisExp.addData('text.stopped', text.tStopRefresh)
#Save data
thisExp.addData("typedWord", text.text)
# the Routine "strategy" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "DONE"-------
t = 0
DONEClock.reset()  # clock
frameN = -1
continueRoutine = True
# update component parameters for each repeat
key_resp_4 = keyboard.Keyboard()
# keep track of which components have finished
DONEComponents = [done, key_resp_4]
for thisComponent in DONEComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

# -------Start Routine "DONE"-------
while continueRoutine:
    # get current time
    t = DONEClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *done* updates
    if t >= 0.0 and done.status == NOT_STARTED:
        # keep track of start time/frame for later
        done.tStart = t  # not accounting for scr refresh
        done.frameNStart = frameN  # exact frame index
        win.timeOnFlip(done, 'tStartRefresh')  # time at next scr refresh
        done.setAutoDraw(True)
    
    # *key_resp_4* updates
    if t >= 0.0 and key_resp_4.status == NOT_STARTED:
        # keep track of start time/frame for later
        key_resp_4.tStart = t  # not accounting for scr refresh
        key_resp_4.frameNStart = frameN  # exact frame index
        win.timeOnFlip(key_resp_4, 'tStartRefresh')  # time at next scr refresh
        key_resp_4.status = STARTED
        # keyboard checking is just starting
        win.callOnFlip(key_resp_4.clock.reset)  # t=0 on next screen flip
        key_resp_4.clearEvents(eventType='keyboard')
    if key_resp_4.status == STARTED:
        theseKeys = key_resp_4.getKeys(keyList=['space'], waitRelease=False)
        if len(theseKeys):
            theseKeys = theseKeys[0]  # at least one key was pressed
            
            # check for quit:
            if "escape" == theseKeys:
                endExpNow = True
            key_resp_4.keys = theseKeys.name  # just the last key pressed
            key_resp_4.rt = theseKeys.rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in DONEComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "DONE"-------
for thisComponent in DONEComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('done.started', done.tStartRefresh)
thisExp.addData('done.stopped', done.tStopRefresh)
# check responses
if key_resp_4.keys in ['', [], None]:  # No response was made
    key_resp_4.keys = None
thisExp.addData('key_resp_4.keys',key_resp_4.keys)
if key_resp_4.keys != None:  # we had a response
    thisExp.addData('key_resp_4.rt', key_resp_4.rt)
thisExp.addData('key_resp_4.started', key_resp_4.tStartRefresh)
thisExp.addData('key_resp_4.stopped', key_resp_4.tStopRefresh)
thisExp.nextEntry()
# the Routine "DONE" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
